#ifndef  _RENDERSETTINGS_H_
#define  _RENDERSETTINGS_H_
#include "DL_TranslatorPlugin.h"
#include "DL_HookPlugin.h"
#define ID_HELPPLUGIN 1050930
#endif // !_RENDERFRAME_H_
#define ID_SDK_EXAMPLE_CUSTOMGUI_STRING 1034666
#define DL_DISPLAY_ON	1051140
#define DL_DISPLAY_OFF	1051141
#define DL_FOLDER_ON	1051142
#define DL_FOLDER_OFF	1051143
#define DL_JPG_ON	1051144
#define DL_JPG_OFF	1051145


class RenderSettings2 : public VideoPostData
{
	

public:
	static NodeData *Alloc(void) { 
		return NewObj(RenderSettings2) iferr_ignore("Wrong Instance");
	}
	virtual Bool Init(GeListNode *node);
	virtual Bool GetDEnabling(GeListNode* node, const DescID& id, const GeData& t_data, DESCFLAGS_ENABLE flags, const BaseContainer* itemdesc);
	virtual Bool GetDDescription(GeListNode *node, Description *description, DESCFLAGS_DESC &flags);
	virtual Bool Message(GeListNode* node, Int32 type, void* data);
	virtual RENDERRESULT Execute(BaseVideoPost* node, VideoPostStruct* vps);

private:
	int ShadingSamples = 50;
	int PixelSampels = 8;
public:
	
	void setShadingSamples(int number) {
		ShadingSamples = number;
	}
	int getShadingSamples(){
		return ShadingSamples;
	}

	int getPixelSamples(){
		return PixelSampels;
	}

	void setPixelSamples(int number) {
		PixelSampels = number;
	}
};
