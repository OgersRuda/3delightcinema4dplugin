#include "c4d.h"
#include "c4d_symbols.h"
#include "myres.h"
#include "3DlghtRenderer.h"
#include <iostream>
#include "DL_Render.h"
#include "DL_SceneParser.h"
#include "nsi.hpp"
#include "IDs.h"
#include <algorithm>

class Modal : public GeDialog {
	INSTANCEOF(Modal, GeDialog);

public:
	virtual Bool CreateLayout();
	virtual Bool Command(Int32 id, const BaseContainer & msg);
};

Bool Modal::CreateLayout() {

	GroupBegin(44, BFH_CENTER | BFV_CENTER, 2, 0, String(), 1, 10, 10);
	AddComboButton(6000, BFH_LEFT, 100, 10, 0);
	BaseContainer children;
	children.SetString(0, "Render"_s);
	children.SetString(1, "Export"_s);
	AddChildren(6000, children);
	GroupEnd();

	return true;
}


Bool ShowDescriptionElement(GeListNode *node, Description *descr, Int32 MyDescID, Bool show)
{
	AutoAlloc<AtomArray> ar; if (!ar) return FALSE;
	ar->Append(static_cast<C4DAtom*>(node));

	BaseContainer *bc = descr->GetParameterI(DescLevel (MyDescID), ar);
	if (bc)
		bc->SetBool(DESC_HIDE, !show);
	else
		return FALSE;

	return TRUE;
}


Bool RenderSettings2::GetDDescription(GeListNode *node, Description *description, DESCFLAGS_DESC &flags) {
	if (!description->LoadDescription(ID_RENDERSETTINGS)) return FALSE;
	flags |= DESCFLAGS_DESC::LOADED;

	BaseContainer *bc = ((BaseTag*)node)->GetDataInstance();
	Bool OPEN_EXR_FORMAT = (bc->GetInt32(DL_DEFAULT_IMAGE_FORMAT) == DL_FORMAT_OPEN_EXR || bc->GetInt32(DL_DEFAULT_IMAGE_FORMAT) == DL_FORMAT_OPEN_EXR_DEEP);
	Bool TIFF_FORMAT = bc->GetInt32(DL_DEFAULT_IMAGE_FORMAT) == DL_FORMAT_TIFF;
	Bool JPG_FORMAT = bc->GetInt32(DL_DEFAULT_IMAGE_FORMAT) == DL_FORMAT_JPEG;
	Bool PNG_FORMAT = bc->GetInt32(DL_DEFAULT_IMAGE_FORMAT) == DL_FORMAT_PNG;

	if (OPEN_EXR_FORMAT)
	{
		ShowDescriptionElement(node, description, DL_DEFAULT_IMAGE_OUTPUT, OPEN_EXR_FORMAT);
		ShowDescriptionElement(node, description, DL_DEFAULT_IMAGE_OUTPUT_TIFF, !OPEN_EXR_FORMAT);
		ShowDescriptionElement(node, description, DL_DEFAULT_IMAGE_OUTPUT_PNG, !OPEN_EXR_FORMAT);
		ShowDescriptionElement(node, description, DL_DEFAULT_IMAGE_OUTPUT_JPG, !OPEN_EXR_FORMAT);
	}

	else if (TIFF_FORMAT) {
		ShowDescriptionElement(node, description, DL_DEFAULT_IMAGE_OUTPUT, !TIFF_FORMAT);
		ShowDescriptionElement(node, description, DL_DEFAULT_IMAGE_OUTPUT_TIFF, TIFF_FORMAT);
		ShowDescriptionElement(node, description, DL_DEFAULT_IMAGE_OUTPUT_PNG, !TIFF_FORMAT);
		ShowDescriptionElement(node, description, DL_DEFAULT_IMAGE_OUTPUT_JPG, !TIFF_FORMAT);
	}

	else if (JPG_FORMAT) {
		ShowDescriptionElement(node, description, DL_DEFAULT_IMAGE_OUTPUT, !JPG_FORMAT);
		ShowDescriptionElement(node, description, DL_DEFAULT_IMAGE_OUTPUT_TIFF, !JPG_FORMAT);
		ShowDescriptionElement(node, description, DL_DEFAULT_IMAGE_OUTPUT_PNG, !JPG_FORMAT);
		ShowDescriptionElement(node, description, DL_DEFAULT_IMAGE_OUTPUT_JPG, JPG_FORMAT);
	}

	else if (PNG_FORMAT) {
		ShowDescriptionElement(node, description, DL_DEFAULT_IMAGE_OUTPUT, !PNG_FORMAT);
		ShowDescriptionElement(node, description, DL_DEFAULT_IMAGE_OUTPUT_TIFF, !PNG_FORMAT);
		ShowDescriptionElement(node, description, DL_DEFAULT_IMAGE_OUTPUT_PNG, PNG_FORMAT);
		ShowDescriptionElement(node, description, DL_DEFAULT_IMAGE_OUTPUT_JPG, !PNG_FORMAT);
	}

	return TRUE;
}



Bool RenderSettings2::GetDEnabling(GeListNode* node, const DescID& id, const GeData& t_data, DESCFLAGS_ENABLE flags, const BaseContainer* itemdesc)
{

	BaseContainer* dldata = ((BaseObject*)node)->GetDataInstance();
	switch (id[0].id)	
	{
	case DL_THIRTYTWO_BIT: {
		String ShadingSample = "Button Sample: " + String::IntToString(getShadingSamples());
		ApplicationOutput(ShadingSample);
		ApplicationOutput(String::IntToString(dldata->GetInt32(DL_PIXEL_SAMPLES)));

		return dldata->GetBool(DL_MOTION_BLUR) == false; break;

	}
	case DL_FRAME_INCREMENT: {return dldata->GetBool(DL_FRAME_RANGE_CHECK) == false; break; }
	case DL_CROP_MIN_FROM: {return dldata->GetBool(DL_IMAGE_CROP_CHECK) == false; break; }
	case DL_CROP_MIN_TO: {return dldata->GetBool(DL_IMAGE_CROP_CHECK) == false; break; }
	case DL_CROP_MAX_FROM: {return dldata->GetBool(DL_IMAGE_CROP_CHECK) == false; break; }
	case DL_CROP_MAX_TO: {return dldata->GetBool(DL_IMAGE_CROP_CHECK) == false; break; }
	}
	return true;
}


Bool RenderSettings2::Message(GeListNode* node, Int32 type, void* data)
{
	switch (type)
	{
	case MSG_DESCRIPTION_COMMAND:
	{
		DescriptionCommand* dc = (DescriptionCommand*)data;
		BaseContainer* dldata = ((BaseVideoPost*)node)->GetDataInstance();
		if (dc->_descId[0].id == DL_CREATE_RENDER_SETTINGS)
		{
			dldata->SetString(DL_ISCLICKED, "Render"_s);
			CallCommand(ID_RENDERFRAME);
		}
		if (dc->_descId[0].id == DL_EXPORT_RENDER_SETTINGS) {
			dldata->SetString(DL_ISCLICKED, "Export"_s);

			if (dldata->GetFilename(DL_FOLDER_OUTPUT).GetString() == "") 
			{
				Filename folder;
				String directory = GeGetStartupApplication().GetString() + "/NSI";
				folder.SetDirectory(directory);
				folder.SetSuffix("nsi"_s);
				folder.FileSelect(FILESELECTTYPE::ANYTHING, FILESELECT::SAVE, "Select Folder"_s);
				dldata->SetFilename(DL_FOLDER_OUTPUT, folder);
			}
			CallCommand(ID_RENDERFRAME);
		}

		break;
	}
	
	case MSG_DESCRIPTION_CHECKUPDATE:
	{
		BaseContainer* dldata = ((BaseVideoPost*)node)->GetDataInstance();
		setShadingSamples(dldata->GetInt32(DL_SHADING_SAMPLES));
		String ShadingSample = "Shading Sample: " + String::IntToString(getShadingSamples());
		String PixelSample = "\nPixel Sample: " + String::IntToString(dldata->GetInt32(DL_PIXEL_SAMPLES));
		String VolumeSample = "\nVolume Sample: " + String::IntToString(dldata->GetInt32(DL_VOLUME_SAMPLES));
		dldata->SetString(DL_TEXTEDIT, ShadingSample + PixelSample + VolumeSample);
	}

	}
	return true;
}

Bool RenderSettings2::Init(GeListNode *node) {


	BaseContainer* dldata = ((BaseVideoPost*)node)->GetDataInstance();
	dldata->SetBool(DL_TEXT_CHECKER, false);
	dldata->SetInt32(DL_SHADING_SAMPLES, 64);
	dldata->SetInt32(DL_PIXEL_SAMPLES, 8);
	dldata->SetInt32(DL_VOLUME_SAMPLES, 16);
	dldata->SetInt32(DL_PIXEL_FILTER, DL_BLACKMAN_HARRIS);
	dldata->SetFloat(DL_FILTER_WIDTH, 2.000);
	dldata->SetBool(DL_MOTION_BLUR, true);
	dldata->SetInt32(DL_MAX_DIFFUSE_DEPTH, 2);
	dldata->SetInt32(DL_MAX_REFLECTION_DEPTH, 2);
	dldata->SetInt32(DL_MAX_REFRACTION_DEPTH, 4);
	dldata->SetInt32(DL_MAX_HAIR_DEPTH, 5);
	dldata->SetFloat(DL_MAX_DISTANCE, 1000);

	dldata->SetInt32(DL_CAMERA_VIEW, DL_CAMERA_PERPSHAPE);
	dldata->SetInt32(DL_ENVIRONMENT_VIEW, DL_ENVIRONMENT_NONE);
	dldata->SetInt32(DL_ATMOSPHERE_VIEW, DL_ATMOSPHERE_NONE);
	dldata->SetInt32(DL_OBJECTS_TO_RENDER_VIEW, DL_OBJECTS_TO_RENDER_ALL);
	dldata->SetInt32(DL_LIGHTS_TO_RENDER_VIEW, DL_LIGHTS_TO_RENDER_ALL);

	dldata->SetBool(DL_FRAME_RANGE_CHECK, true);
	dldata->SetFloat(DL_FRAME_RANGE, 1.000);
	dldata->SetFloat(DL_FRAME_RANGE_MAX, 1.000);
	dldata->SetFloat(DL_FRAME_INCREMENT, 1.000);

	dldata->SetBool(DL_USE_RENDER_IMAGE_SIZE, true);
	dldata->SetFloat(DL_CROP_MIN_FROM, 0.000);
	dldata->SetFloat(DL_CROP_MIN_TO, 0.000);
	dldata->SetFloat(DL_CROP_MAX_FROM, 1.000);
	dldata->SetFloat(DL_CROP_MAX_TO, 1.000);

	dldata->SetInt32(DL_DEFAULT_IMAGE_FORMAT, DL_FORMAT_OPEN_EXR);
	dldata->SetInt32(DL_DEFAULT_IMAGE_OUTPUT, DL_SIXTEEN_BIT_FLOAT);
	dldata->SetInt32(DL_DEFAULT_IMAGE_OUTPUT_TIFF, DL_THIRTYTWO_BIT);
	dldata->SetInt32(DL_DEFAULT_IMAGE_OUTPUT_JPG, DL_EIGHT_BIT);
	dldata->SetInt32(DL_DEFAULT_IMAGE_OUTPUT_PNG, DL_EIGHT_BIT);
	dldata->SetInt32(DL_BATCH_OUTPUT_MODE, DL_ENABLE_AS_SELECTED);
	dldata->SetInt32(DL_INTERACTIVE_OUTPUT_MODE, DL_ENABLE_AS_SELECTED_INTERACTIVE);

	dldata->SetInt32(DL_RESOLUTION, DL_HALF);
	dldata->SetInt32(DL_SAMPLING, DL_TEN_PERCENT);
	dldata->SetFloat(DL_PIXEL_ASPECT_RATIO, 0);
	dldata->RemoveData(DL_EIGHT_BIT);
	
	Filename fn = GeGetStartupPath();
	fn = fn + "\NSI";
	dldata->SetFilename(DL_DEFAULT_IMAGE_FILENAME,fn);

	
	return TRUE;
}



Bool Modal::Command(Int32 id, const BaseContainer &msg)
{

	if (id == 125) {
		LayoutChanged(321);
		EventAdd();
	}

	return true;
}


RENDERRESULT RenderSettings2::Execute(BaseVideoPost* node, VideoPostStruct* vps) {
	BaseContainer* dldata;
	dldata = node->GetDataInstance();
	ApplicationOutput("sdsadsa" + String::IntToString(dldata->GetInt32(DL_SHADING_SAMPLES)));
	return RENDERRESULT::OK;
}




Bool My3DelightRenderPlugin(void)
{
	//PLUGINFLAG_VIDEOPOST_ISRENDERER

	/*Filename fn = GeGetPluginResourcePath() + "display-on.tif";
	AutoAlloc<BaseBitmap> bmp;
	if (IMAGERESULT::OK != bmp->Init(fn))
		return false;*/

	RegisterIcon(DL_DISPLAY_ON, GeGetPluginResourcePath() + "display-on.png");
	RegisterIcon(DL_DISPLAY_OFF, GeGetPluginResourcePath() + "display.png");
	RegisterIcon(DL_FOLDER_ON, GeGetPluginResourcePath() + "folder-on.png");
	RegisterIcon(DL_FOLDER_OFF, GeGetPluginResourcePath() + "folder.png");
	RegisterIcon(DL_JPG_ON, GeGetPluginResourcePath() + "jpg-on.png");
	RegisterIcon(DL_JPG_OFF, GeGetPluginResourcePath() + "jpg.png");

	return RegisterVideoPostPlugin(ID_RENDERSETTINGS, "3Delight Renderer"_s, PLUGINFLAG_VIDEOPOST_ISRENDERER, RenderSettings2::Alloc, "myres"_s, 0, 0);
}	

//
//Bool PluginsHelpDelegate(const maxon::String& opType, const maxon::String& baseType, const maxon::String& group, const maxon::String& property)
//{
//	if (property == "DL_CAMERA_VIEW"_s)
//		// A MessageDialog is shown. Instead, an URL to online or local help could be opened in a browser
//		MessageDialog("Any Camera or Stereo Camera Rig can be selected. If a Stereo Camera Rig is selected, both the Left and Right cameras will be rendered simultaneously"_s);
//
//	if (property == "DL_MOTION_BLUR"_s)
//		MessageDialog("This enables lienar blur with 2 samples. For motion blur with noticeable curvature, additional samples can be specified per object and set."_s);
//
//	return RegisterPluginHelpDelegate(ID_HELPPLUGIN, PluginsHelpDelegate);
//}

// be sure to use a unique ID obtained from www.plugincafe.com

