#ifndef RENDER_OPTIODL_HOOK_H
#define RENDER_OPTIODL_HOOK_H

#include "DL_HookPlugin.h"
#include "c4d.h"
#include <vector>
#include "aov_layers.h"



class RenderOptionsHook:public DL_HookPlugin{
public:
	virtual void CreateNSINodes(BaseDocument* doc, DL_SceneParser* parser);
	virtual void ConnectNSINodes(BaseDocument* doc, DL_SceneParser* parser);

private:
	std::string layer_handle;
	std::string layer_jpg;
	std::string layer_file;
	std::string display_driver_handle;
	std::string file_driver_handle;
	std::string bitmapdriver_handle;
	std::string i_aov;
	std::string i_layertype;
	std::string i_format;
	std::string i_variable_source;
	std::string output_driver_handle;
	std::string m_scalar_format;
	std::string m_extension;
	std::string m_output_format;
};

#endif