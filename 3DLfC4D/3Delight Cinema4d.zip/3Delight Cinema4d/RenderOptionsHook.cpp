#include "RenderOptionsHook.h"
#include "IDs.h"
#include "myres.h"
#include "nsi.hpp"
#include <algorithm>
#include <string.h>
//#include "DL_DataMap.h"
//#include "odisplay.h"
#include "DL_TypeConversions.h"


#define ID_SDK_EXAMPLE_CUSTOMGUI_STRING 1034666
#define ID_CUSTOMDATATYPE_LAYERS 1245668


struct DL_LayersData
{
	Int32 id;
	Char	name[50];
	Char    varName[30];
	Char    varSource[30];
};

DL_LayersData m_shading_components[] =
{
	{ 50,	"RGBA (color + alpha)",      "Ci",				"shader"},
	{ 51,	"Diffuse" ,				     "diffuse",			"shader"},
	{ 52,	"Subsurface scattering",     "subsurface",		"shader"},
	{ 53,	"Reflection",				 "reflection",		"shader"},
	{ 54,	"Refraction",				 "refraction",		"shader"},
	{ 55,	"Incandescence",			 "incandescence",	"shader"},
	{ 0,    "" }
};


DL_LayersData m_auxiliary_variables[] =
{
	{ 100,	 "Z (depth)" ,			     "z",						"builtin"},
	{ 101,   "Camera space position",	 "P.camera",				"builtin"},
	{ 102,   "Camera space normal",		 "N.camera",				"builtin"},
	{ 103,   "UV",						 "uv",						"builtin"},
	{ 104,   "Geometry ID" ,			 "id.geometry",				"builtin"},
	{ 105,   "Scene Path ID",			 "id.scenepath",			"builtin"},
	{ 106,   "Relighting Multiplier",	 "relighting_multiplier",	"shader" },
	{ 0,     "" }
};


string getVariableName(String layer) {
	string m_selected_layer;

	for (int i = 0; m_shading_components[i].id; i++)
	{
		if (layer == String(m_shading_components[i].name))
			m_selected_layer = m_shading_components[i].varName;
	}
			
	for (int i = 0; m_auxiliary_variables[i].id; i++)
	{
		if (layer == String(m_auxiliary_variables[i].name))
			m_selected_layer = m_auxiliary_variables[i].varName;
	}
	
	return m_selected_layer;
}

string getVariableSource(String layer) {
	string m_variable_source;

	for (int i = 0; m_shading_components[i].id; i++)
	{
		if (layer == String(m_shading_components[i].name))
			m_variable_source = m_shading_components[i].varSource;
	}

	for (int i = 0; m_auxiliary_variables[i].id; i++)
	{
		if (layer == String(m_auxiliary_variables[i].name))
			m_variable_source = m_auxiliary_variables[i].varSource;
	}

	return m_variable_source;
}


std::string getFilter(Int32 Id) {
	std::string filter;
	switch (Id)
	{
	case DL_BLACKMAN_HARRIS:
		filter = "blackman-harris"; break;
	case DL_MITCHELL:
		filter = "mitchell"; break;
	case DL_CATMULL_ROM:
		filter = "catmull-rom"; break;
	case DL_SINC:
		filter = "sinc"; break;
	case DL_BOX:
		filter = "box"; break;
	case DL_TRIANGLE:
		filter = "triangle"; break;
	case DL_GAUSSIAN:
		filter = "gaussian"; break;

	default:
		filter = "blackman-harris"; break;
		break;
	}
	return filter;
}


void RenderOptionsHook::CreateNSINodes(BaseDocument* doc, DL_SceneParser* parser){
	NSI::Context ctx(parser->GetContext());
	BaseContainer* settings=parser->GetSettings();
	
	const CustomDataType* dt = settings->GetCustomDataType(DL_CUSTOM_AOV_LAYER, ID_CUSTOMDATATYPE_LAYERS);

	iCustomDataTypeLayers* data = (iCustomDataTypeLayers*)(dt);

	if (!data)
	{ 

		data = NewObjClear(iCustomDataTypeLayers);
		data->_SelectedLayers.Append(String("RGBA (color + alpha)"));
		data->_selectedId.Append(50);
		data->m_output_to_framebuffer.Append(TRUE);
		data->m_output_to_file.Append(TRUE);
		data->m_output_to_jpeg.Append(FALSE);
	}


	double samplingReduceFactor = 1;
	if (settings->GetBool(DL_ENABLE_INTERACTIVE_PREVIEW) == true)
	{
		int sampling = settings->GetInt32(DL_SAMPLING);
		if (sampling == DL_ONE_PERCENT) samplingReduceFactor = 0.01;
		else if (sampling == DL_FOUR_PERCENT) samplingReduceFactor = 0.04;
		else if (sampling == DL_TEN_PERCENT) samplingReduceFactor = 0.10;
		else if (sampling == DL_TWENTYFIVE_PERCENT) samplingReduceFactor = 0.25;
		else if (sampling == DL_HUNDRED_PERCENT) samplingReduceFactor = 1;
	}
	

	NSI::Context context(parser->GetContext());
	
	
	int shading_samples = std::max(1, (int)(settings->GetInt32(DL_SHADING_SAMPLES) *
		samplingReduceFactor + 0.5));

	ctx.SetAttribute(NSI_SCENE_GLOBAL,(
		NSI::IntegerArg("quality.shadingsamples",shading_samples)
		));

	int volume_samples =
		std::max(1, (int)(settings->GetInt32(DL_VOLUME_SAMPLES) *
			samplingReduceFactor + 0.5));

	ctx.SetAttribute(NSI_SCENE_GLOBAL, (
		NSI::IntegerArg("quality.volumesamples", volume_samples)
		));

	int diffuse_depth=settings->GetInt32(DL_MAX_DIFFUSE_DEPTH);
		ctx.SetAttribute(NSI_SCENE_GLOBAL,(
		NSI::IntegerArg("maximumraydepth.diffuse",diffuse_depth)
		));

	int reflection_depth=settings->GetInt32(DL_MAX_REFLECTION_DEPTH);
		ctx.SetAttribute(NSI_SCENE_GLOBAL,(
		NSI::IntegerArg("maximumraydepth.reflection",reflection_depth)
		));

	int refraction_depth=settings->GetInt32(DL_MAX_REFRACTION_DEPTH);
		ctx.SetAttribute(NSI_SCENE_GLOBAL,(
		NSI::IntegerArg("maximumraydepth.refraction",refraction_depth)
		));


		if (data) 
		{
			string filter_output = getFilter(settings->GetInt32(DL_PIXEL_FILTER));
			int m_layer_number = data->_SelectedLayers.GetCount();
			int sortkey = 0;
			if (settings->GetInt32(DL_DEFAULT_IMAGE_FORMAT) == DL_FORMAT_OPEN_EXR || settings->GetInt32(DL_DEFAULT_IMAGE_FORMAT) == DL_FORMAT_OPEN_EXR_DEEP) {
				m_extension = ".exr";
				if (settings->GetInt32(DL_DEFAULT_IMAGE_FORMAT) == DL_FORMAT_OPEN_EXR)
					m_output_format = "exr";
				else
					m_output_format = "deepexr";

				if (settings->GetInt32(DL_DEFAULT_IMAGE_OUTPUT) == DL_SIXTEEN_BIT_FLOAT)
					m_scalar_format = "half";
				else if (settings->GetInt32(DL_DEFAULT_IMAGE_OUTPUT) == DL_THIRTYTWO_BIT)
					m_scalar_format = "float";

				ApplicationOutput("m_scalar @", m_scalar_format.c_str());
			}

			else if(settings->GetInt32(DL_DEFAULT_IMAGE_FORMAT) == DL_FORMAT_TIFF)
			{
				m_extension = ".tif";
				m_output_format = "tiff";
				if (settings->GetInt32(DL_DEFAULT_IMAGE_OUTPUT_TIFF) == DL_EIGHT_BIT)
					m_scalar_format = "uint8";

				else if (settings->GetInt32(DL_DEFAULT_IMAGE_OUTPUT_TIFF) == DL_SIXTEEN_BIT)
					m_scalar_format = "uint16";

				else if (settings->GetInt32(DL_DEFAULT_IMAGE_OUTPUT_TIFF) == DL_THIRTYTWO_BIT)
					m_scalar_format = "float";

				ApplicationOutput("m_scalar @", m_scalar_format.c_str());
			}	
			else if(settings->GetInt32(DL_DEFAULT_IMAGE_FORMAT) == DL_FORMAT_PNG)
			{
				m_extension = ".png";
				m_output_format = "png";
				if (settings->GetInt32(DL_DEFAULT_IMAGE_OUTPUT_PNG) == DL_EIGHT_BIT)
					m_scalar_format = "uint8";

				else if (settings->GetInt32(DL_DEFAULT_IMAGE_OUTPUT_PNG) == DL_SIXTEEN_BIT)
					m_scalar_format = "uint16";

				ApplicationOutput("m_scalar @", m_scalar_format.c_str());
			}
			
			else if(settings->GetInt32(DL_DEFAULT_IMAGE_FORMAT) == DL_FORMAT_JPEG)
			{
				m_extension = ".jpg";
				m_output_format = "jpeg";
				m_scalar_format = "uint8";
				ApplicationOutput("m_scalar @", m_scalar_format.c_str());
			}


			display_driver_handle = "displayDriver";
			ctx.Create(display_driver_handle, "outputdriver");
			ctx.SetAttribute(display_driver_handle, (
				NSI::StringArg("drivername", "idisplay"),
				NSI::StringArg("imagefilename", "Display")
				));

			Filename fn = settings->GetFilename(DL_DEFAULT_IMAGE_FILENAME);
			std::string dir = fn.GetString().GetCStringCopy();

			std::string filename = dir + "\\filename" + m_extension;
			file_driver_handle = "fileDriver";
			ctx.Create(file_driver_handle, "outputdriver");
			ctx.SetAttribute(file_driver_handle, (
				NSI::StringArg("drivername", m_output_format.c_str()),
				NSI::StringArg("imagefilename", filename.c_str())
				));

			ApplicationOutput(filename.c_str());

			for (int i = 0; i < m_layer_number; i++)
			{
				i_aov = getVariableName(data->_SelectedLayers[i]);
				i_variable_source = getVariableSource(data->_SelectedLayers[i]);


				Bool ouputLayerImage = data->m_output_to_jpeg[i];
				Bool outputLayerFile = data->m_output_to_file[i];
				Bool ouputLayerDisplay = data->m_output_to_framebuffer[i];
				String nam = data->_SelectedLayers[i];
				Char* name = nam.GetCStringCopy();
				string extenstion = ".jpg";
				string ouptut_image = dir + "\\" +  name + extenstion;

				if (ouputLayerDisplay) {
					layer_handle = string(parser->GetUniqueName("DisplayLayer"));
					ctx.Create(layer_handle, "outputlayer");
					ctx.SetAttribute(layer_handle, (
						NSI::StringArg("variablename", i_aov.c_str()),
						NSI::StringArg("layername", "display"),
						NSI::StringArg("layertype", "color"),
						NSI::StringArg("variablesource", i_variable_source.c_str()),
						NSI::StringArg("scalarformat", m_output_format.c_str()),
						NSI::IntegerArg("withalpha", 1),
						NSI::IntegerArg("sortkey", sortkey++),
						NSI::StringArg("filter", filter_output.c_str())
						));

					ctx.Connect(layer_handle, "", "scene_camera_screen", "outputlayers");
					ctx.Connect(display_driver_handle, "", layer_handle, "outputdrivers");
				}

				if (outputLayerFile) {
					layer_file = string(parser->GetUniqueName("file_outputlayer"));
					ctx.Create(layer_file, "outputlayer");
					ctx.SetAttribute(layer_file, (
						NSI::StringArg("variablename", i_aov.c_str()),
						NSI::StringArg("layertype", "color"),
						NSI::StringArg("variablesource", i_variable_source.c_str()),
						NSI::StringArg("scalarformat", m_scalar_format.c_str()),
						NSI::IntegerArg("withalpha", 1),
						NSI::IntegerArg("sortkey", sortkey++),
						NSI::StringArg("filter", filter_output.c_str())
						));

					if (m_scalar_format == "uint8")
						ctx.SetAttribute(layer_file, (
							NSI::StringArg("colorprofile", "srgb")
						));

					ctx.Connect(layer_file, "", "scene_camera_screen", "outputlayers");
					ctx.Connect(file_driver_handle, "", layer_file, "outputdrivers");

				}

				if (ouputLayerImage) {
					layer_jpg = string(parser->GetUniqueName("image_outputlayer"));
					ctx.Create(layer_jpg, "outputlayer");
					ctx.SetAttribute(layer_jpg, (
						NSI::StringArg("variablename", i_aov.c_str()),
						NSI::StringArg("layertype", "color"),
						NSI::StringArg("variablesource", i_variable_source.c_str()),
						NSI::StringArg("scalarformat", "uint8"),
						NSI::IntegerArg("withalpha", 1),
						NSI::IntegerArg("sortkey", sortkey++),
						NSI::StringArg("filter", filter_output.c_str()),
						NSI::StringArg("colorprofile", "srgb")
						));


					output_driver_handle = string(parser->GetUniqueName("driver"));
					ctx.Create(output_driver_handle, "outputdriver");
					ctx.SetAttribute(output_driver_handle, (
						NSI::StringArg("drivername", "jpeg"),
						NSI::StringArg("imagefilename", ouptut_image.c_str())
						));
					ctx.Connect(output_driver_handle, "", layer_jpg, "outputdrivers");
					ctx.Connect(layer_jpg, "", "scene_camera_screen", "outputlayers");
				}

			}
		}
		


}

void RenderOptionsHook::ConnectNSINodes(BaseDocument* doc, DL_SceneParser* parser){
	NSI::Context ctx(parser->GetContext());
}
