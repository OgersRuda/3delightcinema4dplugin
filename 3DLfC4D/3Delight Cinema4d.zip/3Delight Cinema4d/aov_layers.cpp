#include "aov_layers.h"
#include "c4d_basebitmap.h"
#include "c4d_symbols.h"
#include <list>
#include <vector>
#include <string>
#include <algorithm>
#include <map>
#include "3DlghtRenderer.h"

using namespace std;

#define ID_CUSTOMGUI_LAYERS 1034668
#define ID_CUSTOMDATATYPE_LAYERS 1245668


struct LayersData
{
	Int32 id;
	Char	name[50];
};

LayersData m_shading_components[] =
{
	{ 50, "RGBA (color + alpha)" },
	{ 51, "Diffuse" },
	{ 52, "Subsurface scattering" },
	{ 53, "Reflection" },
	{ 54, "Refraction" },
	{ 55, "Incandescence" },
	{ 0, "" }
};


LayersData m_auxiliary_variables[] =
{
	{ 100, "Z (depth)" },
	{ 101, "Camera space position" },
	{ 102, "Camera space normal" },
	{ 103, "UV" },
	{ 104, "Geometry ID" },
	{ 105, "Scene Path ID" },
	{ 106, "Relighting Multiplier" },
	{ 0, "" }
};




static void ApplicationOutputF(const Char* format, ...)
{
	va_list arp;
	Char		buf[1024];

	va_start(arp, format);
	vsprintf_safe(buf, sizeof(buf), format, arp);
	ApplicationOutput(String(buf));
	va_end(arp);
}



class iCustomDataTypeAOV : public iCustomGui

{
	INSTANCEOF(iCustomDataTypeAOV, iCustomGui)

private:

	iCustomDataTypeLayers _data;
	AOVDialog _dialog;
	Bool _tristate; 
	SimpleListView				Aov_Listview;
	AutoAlloc<BaseSelect>	selection;
	void UpdateButtons();

public:
	iCustomDataTypeAOV(const BaseContainer &settings, CUSTOMGUIPLUGIN *plugin);
	virtual Bool CreateLayout();
	virtual Bool InitValues();
	virtual Bool Command(Int32 id, const BaseContainer &msg);
	virtual Bool SetData(const TriState<GeData> &tristate);
	virtual TriState<GeData> GetData();
};


iCustomDataTypeAOV::iCustomDataTypeAOV(const BaseContainer &settings, CUSTOMGUIPLUGIN *plugin) : iCustomGui(settings, plugin)
{
	_tristate = false;
};

Bool iCustomDataTypeAOV::CreateLayout()
{
		Bool m_layout_create = GeDialog::CreateLayout();

		m_layout_create = LoadDialogResource(AOV_SELECTOR, nullptr, 0);

		if (m_layout_create)
		{
			Aov_Listview.AttachListView(this, DL_SELECTED_LAYERS_LISTVIEW);
		}
		_dialog._data = &_data;

	return SUPER::CreateLayout();
};

void iCustomDataTypeAOV::UpdateButtons()
{

	if (!selection) {
		Enable(AOV_ADD, FALSE);
		return;
	}
	Enable(AOV_REMOVE, Aov_Listview.GetSelection(selection) != 0);
	Enable(AOV_DUPLICATE, Aov_Listview.GetSelection(selection) != 0);
	Enable(AOV_VIEW, Aov_Listview.GetSelection(selection) != 0);
}


Bool iCustomDataTypeAOV::InitValues()
{
	
	BaseContainer layout;
	BaseContainer data;
	Int32 ItemId = 1;
	Aov_Listview.SetProperty(SLV_MULTIPLESELECTION, true);

	layout = BaseContainer();
	layout.SetInt32('Dspl', LV_COLUMN_BMP);
	layout.SetInt32('Fldr', LV_COLUMN_BMP);
	layout.SetInt32('Jpg', LV_COLUMN_BMP);
	layout.SetInt32('name', LV_COLUMN_TEXT);
	Aov_Listview.SetLayout(4, layout);


	if (_data._SelectedLayers.GetCount() == 0) {
		_data._SelectedLayers.Append(maxon::String(m_shading_components[0].name));
		_data._selectedId.Append(maxon::Int32(m_shading_components[0].id));
		_data.m_output_to_framebuffer.Append(TRUE);
		_data.m_output_to_file.Append(TRUE);
		_data.m_output_to_jpeg.Append(FALSE);
	}

	for (auto &value : _data._SelectedLayers)
	{
		Int32 Position = ItemId - 1;
		maxon::String name = value;
		data.SetString('name', maxon::String(name));
		data.SetInt32('Dspl', _data.m_output_to_framebuffer[Position] ? DL_DISPLAY_ON : DL_DISPLAY_OFF);
		data.SetInt32('Fldr', _data.m_output_to_file[Position] ? DL_FOLDER_ON : DL_FOLDER_OFF);
		data.SetInt32('Jpg', _data.m_output_to_jpeg[Position] ? DL_JPG_ON : DL_JPG_OFF);
		Aov_Listview.SetItem(ItemId++, data);

	}
	Aov_Listview.DataChanged();
	UpdateButtons();

	return SUPER::InitValues();
};

AOVDialog::AOVDialog()
{
	_data = NULL;
}

AOVDialog::~AOVDialog()
{
}


Bool AOVDialog::CreateLayout()
{
	// first call the parent instance

	Bool m_aov_selector = GeDialog::CreateLayout();

	m_aov_selector = LoadDialogResource(AOV_SELECTOR_DIALOG, nullptr, 0);

	if (m_aov_selector)
	{
		Shading_Listview.AttachListView(this, DL_SHADING_COMPONENTS_LISTVIEW);
		Auxiliary_Listview.AttachListView(this, DL_AUXILIARY_COMPONENTS_LISTVIEW);
	}

	if (_data->_SelectedLayers.GetCount() == 0) {
		_data->_SelectedLayers.Append(maxon::String(m_shading_components[0].name));
		_data->_selectedId.Append(maxon::Int32(m_shading_components[0].id));
		_data->m_output_to_framebuffer.Append(TRUE);
		_data->m_output_to_file.Append(TRUE);
		_data->m_output_to_jpeg.Append(FALSE);
	}

	AutoAlloc<BaseSelect> selected;
	for (auto &value : _data->_selectedId) {

		selected->Select(value);
		Auxiliary_Listview.SetSelection(selected);
		Shading_Listview.SetSelection(selected);
	}

	return m_aov_selector;
}


void AOVDialog::UpdateButtons()
{
	if (!selection)
		return;

	Enable(BUTTON_OK, Shading_Listview.GetSelection(selection) != 0);
	Enable(BUTTON_OK, Auxiliary_Listview.GetSelection(selection) != 0);
	Enable(BUTTON_CANCEL, TRUE);
}

Bool AOVDialog::InitValues()
{
	// first call the parent instance
	if (!GeDialog::InitValues())
		return false;

	BaseContainer layout;
	BaseContainer data;
	Int32 i = 0;

	layout = BaseContainer();
	layout.SetInt32('name', LV_COLUMN_TEXT);
	Shading_Listview.SetLayout(1, layout);
	Shading_Listview.SetProperty(SLV_MULTIPLESELECTION, TRUE);

	layout = BaseContainer();
	layout.SetInt32('name', LV_COLUMN_TEXT);
	Auxiliary_Listview.SetLayout(1, layout);
	Auxiliary_Listview.SetProperty(SLV_MULTIPLESELECTION, TRUE);


	data = BaseContainer();
	for (i = 0; m_shading_components[i].id; i++)
	{
		data.SetString('name', String(m_shading_components[i].name));
		Shading_Listview.SetItem(m_shading_components[i].id, data);
	}

	data = BaseContainer();
	for (i = 0; m_auxiliary_variables[i].id; i++)
	{
		data.SetString('name', String(m_auxiliary_variables[i].name));
		Auxiliary_Listview.SetItem(m_auxiliary_variables[i].id, data);
	}

	Shading_Listview.DataChanged();
	Auxiliary_Listview.DataChanged();
	UpdateButtons();

	return true;
}



Int32 AOVDialog::Message(const BaseContainer& msg, BaseContainer& result)
{
	{
	}
	return GeDialog::Message(msg, result);
}



Bool iCustomDataTypeAOV::Command(Int32 id, const BaseContainer &msg)
{
	switch (id)
	{
	case DL_SELECTED_LAYERS_LISTVIEW:
	{
		if (_data._SelectedLayers.GetCount() == 0)
		{
			_data._SelectedLayers.Append(maxon::String(m_shading_components[0].name));
			_data._selectedId.Append(maxon::Int32(m_shading_components[0].id));
			_data.m_output_to_framebuffer.Append(TRUE);
			_data.m_output_to_file.Append(TRUE);
			_data.m_output_to_jpeg.Append(FALSE);
		}

		switch (msg.GetInt32(BFM_ACTION_VALUE))
		{
		case LV_SIMPLE_SELECTIONCHANGED:
			ApplicationOutputF("Selection changed, id: %d, val: %p ", msg.GetInt32(LV_SIMPLE_ITEM_ID), msg.GetVoid(LV_SIMPLE_DATA));
			break;

		case LV_SIMPLE_CHECKBOXCHANGED:
			ApplicationOutputF("CheckBox changed, id: %d, col: %d, val: %p", msg.GetInt32(LV_SIMPLE_ITEM_ID), msg.GetInt32(LV_SIMPLE_COL_ID), msg.GetVoid(LV_SIMPLE_DATA));
			break;

		case LV_SIMPLE_FOCUSITEM:
			ApplicationOutputF("Focus set id: %d, col: %d", msg.GetInt32(LV_SIMPLE_ITEM_ID), msg.GetInt32(LV_SIMPLE_COL_ID));
			break;

		case LV_SIMPLE_BUTTONCLICK:
			ApplicationOutputF("Button clicked id: %d, col: %d", msg.GetInt32(LV_SIMPLE_ITEM_ID), msg.GetInt32(LV_SIMPLE_COL_ID));
			break;
		}
		
	
		Int32 Column = msg.GetInt32(LV_SIMPLE_COL_ID);
		if (Column == 'Dspl') {
			BaseContainer data;
			Int32 SelectedItemId = msg.GetInt32(LV_SIMPLE_ITEM_ID);
			Aov_Listview.GetItem(SelectedItemId, &data);
			Int32 CurrIconId = data.GetInt32('Dspl');
			String SelectedItemName = data.GetString('name');
			Int32 Pos = SelectedItemId - 1;
			switch (CurrIconId)
			{
			case DL_DISPLAY_ON:
				_data.m_output_to_framebuffer[Pos] = FALSE;
				data.SetInt32('Dspl',_data.m_output_to_framebuffer[Pos] ? DL_DISPLAY_ON : DL_DISPLAY_OFF);
				break;
			case DL_DISPLAY_OFF:
				_data.m_output_to_framebuffer[Pos] = TRUE;
				data.SetInt32('Dspl', _data.m_output_to_framebuffer[Pos] ? DL_DISPLAY_ON : DL_DISPLAY_OFF);
				break;
			default:
				_data.m_output_to_framebuffer[Pos] = TRUE;
				break;
			}

			Aov_Listview.SetItem(SelectedItemId, data);
			Aov_Listview.DataChanged();

		}

		else if (Column == 'Fldr') {
			BaseContainer data;
			Int32 SelectedItemId = msg.GetInt32(LV_SIMPLE_ITEM_ID);
			Aov_Listview.GetItem(SelectedItemId, &data);
			Int32 CurrIconId = data.GetInt32('Fldr');
			String SelectedItemName = data.GetString('name');
			Int32 Pos = SelectedItemId - 1;

			switch (CurrIconId)
			{
			case DL_FOLDER_ON:
				_data.m_output_to_file[Pos] = FALSE;
				data.SetInt32('Fldr', _data.m_output_to_file[Pos] ? DL_FOLDER_ON : DL_FOLDER_OFF);
				break;
			case DL_FOLDER_OFF:
				_data.m_output_to_file[Pos] = TRUE;
				data.SetInt32('Fldr', _data.m_output_to_file[Pos] ? DL_FOLDER_ON : DL_FOLDER_OFF);
				break;
			default:
				_data.m_output_to_file[Pos] = TRUE;
				break;
			}

			Aov_Listview.SetItem(SelectedItemId, data);
			Aov_Listview.DataChanged();
		}

		else if (Column == 'Jpg') {
			BaseContainer data;
			Int32 SelectedItemId = msg.GetInt32(LV_SIMPLE_ITEM_ID);
			Aov_Listview.GetItem(SelectedItemId, &data);
			Int32 CurrIconId = data.GetInt32('Jpg');
			String SelectedItemName = data.GetString('Jpg');
			Int32 Pos = SelectedItemId - 1;

			switch (CurrIconId)
			{
			case DL_JPG_ON:
				_data.m_output_to_jpeg[Pos] = FALSE;
				data.SetInt32('Jpg', _data.m_output_to_jpeg[Pos] ? DL_JPG_ON : DL_JPG_OFF);
				break;
			case DL_JPG_OFF:
				_data.m_output_to_jpeg[Pos] = TRUE;
				data.SetInt32('Jpg', _data.m_output_to_jpeg[Pos] ? DL_JPG_ON : DL_JPG_OFF);
				break;
			default:
				_data.m_output_to_jpeg[Pos] = TRUE;
				break;
			}

			Aov_Listview.SetItem(SelectedItemId, data);
			Aov_Listview.DataChanged();
		}

		UpdateButtons();
		break;
	
	}

	case AOV_ADD:
	{

		_data.check = true;
		Int32 Size = Aov_Listview.GetItemCount(); //Get size before ListView is updated otherwise it will cause malfunction 
		_dialog.Open(DLG_TYPE::MODAL, 10, -1, -1, 500, 200);

		if (!_data.check)
		{

			for (int i = 1; i <= Size; i++) {
				Aov_Listview.RemoveItem(i);
			}
			
			maxon::BaseArray<Int32> removedData;
			Int32 ItemId = 1;
			BaseContainer data;
			Int32 pos = 0; //Position in the array
			for (auto &value : _data._selectedId) {
				//if selected layer not found in aov_selector remove it
				if (!(_dialog.m_selectedID.Contains(value)))
				{
					removedData.Append(pos);
				}
				pos++;
			}

			Int32 decrement = 0;
			for (auto &value : removedData) {
				Int32 ID = value-decrement; //Arary size is decreased by 1 each time we remove
				_data._SelectedLayers.Erase(ID);
				_data._selectedId.Erase(ID);
				_data.m_output_to_framebuffer.Erase(ID);
				_data.m_output_to_file.Erase(ID);
				_data.m_output_to_jpeg.Erase(ID);
				decrement++;
			}

			for (auto &value : _dialog.m_selectedID)
			{
				Int32 Id = value;
				if (!(_data._selectedId.Contains(Id)))
				{
					_data._selectedId.Append(Id);
				}
			}

			for (auto &value : _dialog.m_selected)
			{
				String name = value;
				if (!(_data._SelectedLayers.Contains(name)))
				{
					_data._SelectedLayers.Append(name);
					_data.m_output_to_framebuffer.Append(TRUE);
					_data.m_output_to_file.Append(TRUE);
					_data.m_output_to_jpeg.Append(FALSE);
				}
	
			}


			if (_data._SelectedLayers.GetCount() == 0)
			{
				_data._SelectedLayers.Append(maxon::String(m_shading_components[0].name));
				_data._selectedId.Append(maxon::Int32(m_shading_components[0].id));
				_data.m_output_to_framebuffer.Append(TRUE);
				_data.m_output_to_file.Append(TRUE);
				_data.m_output_to_jpeg.Append(FALSE);
			}


			for (auto &value : _data._SelectedLayers)
			{
				Int32 Position = ItemId - 1;
				maxon::String name = value;
				data.SetString('name', maxon::String(name));
				data.SetInt32('Dspl', _data.m_output_to_framebuffer[Position] ? DL_DISPLAY_ON : DL_DISPLAY_OFF);
				data.SetInt32('Fldr', _data.m_output_to_file[Position] ? DL_FOLDER_ON : DL_FOLDER_OFF);
				data.SetInt32('Jpg', _data.m_output_to_jpeg[Position] ? DL_JPG_ON : DL_JPG_OFF);
				Aov_Listview.SetItem(ItemId++, data);

			}

			Aov_Listview.DataChanged();
		}
		break;
	}



	case AOV_REMOVE: {

		Int Size = Aov_Listview.GetItemCount();
		Int32 i, a, b, dec = 1;
		Int32 RemPos = 0;
		Int32 pos = -1;
		for (i = 0; selection->GetRange(i, LIMIT<Int32>::MAX, &a, &b); i++)
		{
			for (; a <= b; a++)
			{
				{
					Int32 SelectedItemId = a - dec;

					_data._SelectedLayers.Erase(SelectedItemId);
					_data._selectedId.Erase(SelectedItemId);
					_data.m_output_to_framebuffer.Erase(SelectedItemId);
					_data.m_output_to_file.Erase(SelectedItemId);
					_data.m_output_to_jpeg.Erase(SelectedItemId);

					dec++;
				}

			}
		}

		for (Int i = 1; i <= Size; i++)
		{
			ApplicationOutput(String::IntToString(i));
			Aov_Listview.RemoveItem(i);
		}

		ApplicationOutput(String::IntToString(Aov_Listview.GetItemCount()));

		Int ItemId = 1;
		BaseContainer data;


		if (_data._SelectedLayers.GetCount() == 0)
		{
			_data._SelectedLayers.Insert(0, maxon::String(m_shading_components[0].name));
			_data._selectedId.Insert(0, maxon::Int32(m_shading_components[0].id));
			_data.m_output_to_framebuffer.Append(TRUE);
			_data.m_output_to_file.Append(TRUE);
			_data.m_output_to_jpeg.Append(FALSE);
		}


		for (auto &value : _data._SelectedLayers)
		{
			Int32 Position = ItemId - 1;
			maxon::String name = value;
			data.SetString('name', maxon::String(name));
			data.SetInt32('Dspl', _data.m_output_to_framebuffer[Position] ? DL_DISPLAY_ON : DL_DISPLAY_OFF);
			data.SetInt32('Fldr', _data.m_output_to_file[Position] ? DL_FOLDER_ON : DL_FOLDER_OFF);
			data.SetInt32('Jpg', _data.m_output_to_jpeg[Position] ? DL_JPG_ON : DL_JPG_OFF);
			Aov_Listview.SetItem(ItemId++, data);

		}

		Aov_Listview.DataChanged();
		UpdateButtons();
		break;
	}

	case AOV_DUPLICATE:
	{
		AutoAlloc<BaseSelect> s2;
		if (selection && s2)
		{
			Int32 i, id2, count = Aov_Listview.GetItemCount();
			Int32 cnt = 0;
			BaseContainer test;

			for (i = 0; i < count; i++)
			{
				Aov_Listview.GetItemLine(i, &id2, &test);
			}

			if (!Aov_Listview.GetSelection(selection))
			{
				ApplicationOutput("No Selection"_s);
			}
			else
			{
				Int32	 a, b;
				String str;
				for (i = 0; selection->GetRange(i, LIMIT<Int32>::MAX, &a, &b); i++)
				{
					if (a == b)
						str += String::IntToString(a) + " ";
					else
						str += String::IntToString(a) + "-" + String::IntToString(b) + " ";
				}
				ApplicationOutput("Selection: " + str);

				BaseContainer data;
				AutoAlloc<BaseSelect> SelectedDuplicate;

				for (int i = 1; i <= count; i++)
				{
					ApplicationOutput(String::IntToString(count) + "  " + String::IntToString(i));

					if (selection->IsSelected(i))
					{
						String name = _data._SelectedLayers[i - 1];
						Bool framebuffer = _data.m_output_to_framebuffer[i - 1];
						Bool file = _data.m_output_to_file[i - 1];
						Bool jpeg = _data.m_output_to_jpeg[i - 1];
						Int32 SelectedID = _data._selectedId[i-1];
	
						Int32 Position = count;
						
						_data._SelectedLayers.Append(name);
						_data._selectedId.Append(SelectedID);
						_data.m_output_to_framebuffer.Append(framebuffer);
						_data.m_output_to_file.Append(file);
						_data.m_output_to_jpeg.Append(jpeg);
					
						data.SetString('name', name);
						data.SetInt32('Dspl', _data.m_output_to_framebuffer[Position] ? DL_DISPLAY_ON : DL_DISPLAY_OFF);
						data.SetInt32('Fldr', _data.m_output_to_file[Position] ? DL_FOLDER_ON : DL_FOLDER_OFF);
						data.SetInt32('Jpg', _data.m_output_to_jpeg[Position] ? DL_JPG_ON : DL_JPG_OFF);
						Aov_Listview.SetItem(++count, data);
						SelectedDuplicate->Select(count);
						ApplicationOutput(String::IntToString(count));

					}
				}

				Aov_Listview.SetSelection(SelectedDuplicate);
				Aov_Listview.DataChanged();

			}
		}
		UpdateButtons();
		break;
	}

	case AOV_VIEW:
	{
		
		system("C:\\Users\\Ogers\\Documents\\filename.exr");
	}

	}

	BaseContainer m(msg);
	m.SetInt32(BFM_ACTION_ID, GetId());
	m.SetData(BFM_ACTION_VALUE, this->GetData().GetValue());
	SendParentMessage(m);

	Aov_Listview.DataChanged();
	return true;
}



Bool AOVDialog::Command(Int32 id, const BaseContainer& msg)
{
	switch (id)
	{
	case DL_SHADING_COMPONENTS_LISTVIEW:
	case DL_AUXILIARY_COMPONENTS_LISTVIEW:
	{
		switch (msg.GetInt32(BFM_ACTION_VALUE))
		{
		case LV_SIMPLE_SELECTIONCHANGED:
			ApplicationOutputF("Selection changed, id: %d, val: %p ", msg.GetInt32(LV_SIMPLE_ITEM_ID), msg.GetVoid(LV_SIMPLE_DATA));
			break;

		case LV_SIMPLE_CHECKBOXCHANGED:
			ApplicationOutputF("CheckBox changed, id: %d, col: %d, val: %p", msg.GetInt32(LV_SIMPLE_ITEM_ID), msg.GetInt32(LV_SIMPLE_COL_ID), msg.GetVoid(LV_SIMPLE_DATA));
			break;

		case LV_SIMPLE_FOCUSITEM:
			ApplicationOutputF("Focus set id: %d, col: %d", msg.GetInt32(LV_SIMPLE_ITEM_ID), msg.GetInt32(LV_SIMPLE_COL_ID));
			break;

		case LV_SIMPLE_BUTTONCLICK:
			ApplicationOutputF("Button clicked id: %d, col: %d", msg.GetInt32(LV_SIMPLE_ITEM_ID), msg.GetInt32(LV_SIMPLE_COL_ID));
			break;
		}
		UpdateButtons();
		break;
	}


	case BUTTON_OK:
	{
		m_selected.Reset();
		m_selectedID.Reset();
		_data->check = false;
		AutoAlloc<BaseSelect> s2;
		if (selection && s2)
		{
			Int32					i, id2, count = Shading_Listview.GetItemCount();
			BaseContainer test;

			for (i = 0; i < count; i++)
			{
				Shading_Listview.GetItemLine(i, &id2, &test);
			}

			if (!Shading_Listview.GetSelection(selection))
			{
				ApplicationOutput("No Selection"_s);
			}
			else
			{
				Int32	 a, b;
				String str;
				for (i = 0; selection->GetRange(i, LIMIT<Int32>::MAX, &a, &b); i++)
				{
					if (a == b)
						str += String::IntToString(a) + " ";
					else
						str += String::IntToString(a) + "-" + String::IntToString(b) + " ";
				}
				ApplicationOutput("Selection: " + str);

				BaseContainer data;
				for (i = 0; m_shading_components[i].id; i++)
				{
					if (selection->IsSelected(m_shading_components[i].id))
					{
						maxon::String name = maxon::String(m_shading_components[i].name);
						maxon::Int32 Id = maxon::Int32(m_shading_components[i].id);
						m_selected.Append(m_shading_components[i].name);
						m_selectedID.Append(m_shading_components[i].id);
					
					}
				}
			}
		}

		AutoAlloc<BaseSelect> s3;
		if (selection && s3)
		{
			Int32					i, id2, count = Auxiliary_Listview.GetItemCount();
			BaseContainer test;

			for (i = 0; i < count; i++)
			{
				Auxiliary_Listview.GetItemLine(i, &id2, &test);
			}

			if (!Auxiliary_Listview.GetSelection(selection))
			{
				ApplicationOutput("No Selection"_s);
			}
			else
			{
				Int32	 a, b;
				String str;
				for (i = 0; selection->GetRange(i, LIMIT<Int32>::MAX, &a, &b); i++)
				{
					if (a == b)
						str += String::IntToString(a) + " ";
					else
						str += String::IntToString(a) + "-" + String::IntToString(b) + " ";
				}

				ApplicationOutput("Selection: " + str);

				BaseContainer data;
				for (i = 0; m_auxiliary_variables[i].id; i++)
				{
					if (selection->IsSelected(m_auxiliary_variables[i].id))
					{
						maxon::String name = maxon::String(m_auxiliary_variables[i].name);
						maxon::Int32 Id = maxon::Int32(m_auxiliary_variables[i].id);
						m_selected.Append(m_auxiliary_variables[i].name);
						m_selectedID.Append(m_auxiliary_variables[i].id);

					}
				}
			}
		}
		
		UpdateButtons();
		this->Close();
		break;
	}

	case BUTTON_CANCEL:
	{
		this->Close();
		break;
	}

	}
	return true;
}


Bool iCustomDataTypeAOV::SetData(const TriState<GeData> &tristate)
{
	
	iCustomDataTypeLayers* data = (iCustomDataTypeLayers*)(tristate.GetValue().GetCustomDataType(ID_CUSTOMDATATYPE_LAYERS));
	if (data)
	{
		iferr(_data._SelectedLayers.CopyFrom(data->_SelectedLayers))
			return false;

		iferr(_data._selectedId.CopyFrom(data->_selectedId))
			return false;

		iferr(_data.m_output_to_framebuffer.CopyFrom(data->m_output_to_framebuffer))
			return false;

		iferr(_data.m_output_to_file.CopyFrom(data->m_output_to_file))
			return false;

		iferr(_data.m_output_to_jpeg.CopyFrom(data->m_output_to_jpeg))
			return false;

		_data.check = data->check;
		
		Aov_Listview.DataChanged();
	}

	return true;
};




TriState<GeData> iCustomDataTypeAOV::GetData()
{
	TriState<GeData> tri;
	tri.Add(GeData(ID_CUSTOMDATATYPE_LAYERS, _data));
	return tri;
};

static Int32 g_stringtable[] = { ID_CUSTOMDATATYPE_LAYERS }; /// This array defines the applicable datatypes.


//---------------------
/// This CustomGuiData class registers a new custom GUI for the Layers datatype.
//---------------------
class DelightCustonGuiLayers : public CustomGuiData
{
public:
	virtual Int32 GetId();
	virtual CDialog* Alloc(const BaseContainer& settings);
	virtual void Free(CDialog* dlg, void* userdata);
	virtual const Char* GetResourceSym();
	virtual CustomProperty* GetProperties();
	virtual Int32 GetResourceDataType(Int32*& table);

};



Int32 DelightCustonGuiLayers::GetId()
{
	return ID_CUSTOMGUI_LAYERS;
};


CDialog* DelightCustonGuiLayers::Alloc(const BaseContainer& settings)
{
	iferr(iCustomDataTypeAOV* dlg = NewObj(iCustomDataTypeAOV, settings, GetPlugin()))
		return nullptr;

	CDialog *cdlg = dlg->Get();

	if (!cdlg)
		return nullptr;

	return cdlg;
};



void DelightCustonGuiLayers::Free(CDialog* dlg, void* userdata)
{
	if (!dlg || !userdata)
		return;

	iCustomDataTypeAOV* sub = static_cast<iCustomDataTypeAOV*>(userdata);
	DeleteObj(sub);
};

const Char* DelightCustonGuiLayers::GetResourceSym()
{
	// Returns the resource symbol. This symbol can be used in resource files in combination with "CUSTOMGUI".
	return "DELIGHTLAYERCUSTOMGUI";
};

CustomProperty* DelightCustonGuiLayers::GetProperties()
{
	return nullptr;
};

Int32 DelightCustonGuiLayers::GetResourceDataType(Int32*& table)
{
	// Returns the applicable datatypes defined in the stringtable array.
	table = g_stringtable;
	return sizeof(g_stringtable) / sizeof(Int32);
};

class LayersCustomDataTypeClass : public CustomDataTypeClass
{
	INSTANCEOF(LayersCustomDataTypeClass, CustomDataTypeClass)

public:
	virtual Int32 GetId()
	{
		return ID_CUSTOMDATATYPE_LAYERS;
	}

	virtual CustomDataType* AllocData()
	{
		iCustomDataTypeLayers* data = NewObjClear(iCustomDataTypeLayers);
		return data;
	};

	virtual void FreeData(CustomDataType* data)
	{
		iCustomDataTypeLayers* d = static_cast<iCustomDataTypeLayers*>(data);
		DeleteObj(d);
	}

	virtual Bool CopyData(const CustomDataType* src, CustomDataType* dst, AliasTrans* aliastrans)
	{
		// copy the data to the given target data

		iCustomDataTypeLayers* s = (iCustomDataTypeLayers*)(src);
		iCustomDataTypeLayers* d = (iCustomDataTypeLayers*)(dst);

		if (!s || !d)
			return false;

		d->_SelectedLayers.Flush();
		iferr(d->_SelectedLayers.CopyFrom(s->_SelectedLayers))
			return false;

		d->_selectedId.Flush();
		iferr(d->_selectedId.CopyFrom(s->_selectedId))
			return false;

		d->m_output_to_framebuffer.Flush();
		iferr(d->m_output_to_framebuffer.CopyFrom(s->m_output_to_framebuffer))
			return false;

		d->m_output_to_file.Flush();
		iferr(d->m_output_to_file.CopyFrom(s->m_output_to_file))
			return false;

		d->m_output_to_jpeg.Flush();
		iferr(d->m_output_to_jpeg.CopyFrom(s->m_output_to_jpeg))
			return false;

		d->check = s->check;
		
		return true;
	}

	virtual Int32 Compare(const CustomDataType* d1, const CustomDataType* d2)
	{
		return 1;
	}

	virtual Bool WriteData(const CustomDataType* t_d, HyperFile* hf)
	{
		const iCustomDataTypeLayers* const d = static_cast<const iCustomDataTypeLayers*>(t_d);

		const maxon::Int length = d->_SelectedLayers.GetCount();
		hf->WriteInt64((Int64)length);

		for (Int64 i = 0; i < length; ++i)
		{
			hf->WriteString(d->_SelectedLayers[i]);
			hf->WriteInt32(d->_selectedId[i]);
			hf->WriteBool(d->m_output_to_framebuffer[i]);
			hf->WriteBool(d->m_output_to_file[i]);
			hf->WriteBool(d->m_output_to_jpeg[i]);
			
		}

		return true;
	}

	virtual Bool ReadData(CustomDataType* t_d, HyperFile* hf, Int32 level)
	{

		iCustomDataTypeLayers* const d = static_cast<iCustomDataTypeLayers*>(t_d);

		if (level > 0)
		{
			Int64 length = 0;
			if (hf->ReadInt64(&length))
			{
				for (Int64 i = 0; i < length; ++i)
				{
					String layer;
					Int32 layerId;
					Bool output_to_framebuffer;
					Bool output_to_file;
					Bool output_to_jpeg;
					if (hf->ReadString(&layer))
					{
						iferr(d->_SelectedLayers.Append(layer))
							return false;
					}

					if (hf->ReadInt32(&layerId)) {
						iferr(d->_selectedId.Append(layerId))
							return false;
					}

					if (hf->ReadBool(&output_to_framebuffer)) {
						iferr(d->m_output_to_framebuffer.Append(output_to_framebuffer))
							return false;
					}

					if (hf->ReadBool(&output_to_file)) {
						iferr(d->m_output_to_file.Append(output_to_file))
							return false;
					}

					if (hf->ReadBool(&output_to_jpeg)) {
						iferr(d->m_output_to_jpeg.Append(output_to_jpeg))
							return false;
					}
				}
			}
		}

		return true;
	}


	virtual const Char* GetResourceSym()
	{
		// this symbol can be used in resource files
		return "DELIGHTLAYERCUSTOMTYPE";
	}

	virtual void GetDefaultProperties(BaseContainer &data)
	{
		// the default values of this datatype
		// use the custom GUI as default
		data.SetInt32(DESC_CUSTOMGUI, ID_CUSTOMGUI_LAYERS);
		data.SetInt32(DESC_ANIMATE, DESC_ANIMATE_ON);
	}
};


Bool RegisterCustomListView()
{
	if (!RegisterCustomDataTypePlugin(
		GeLoadString(IDS_CUSTOMDATATYPE_DOTS),
		CUSTOMDATATYPE_INFO_LOADSAVE |
		CUSTOMDATATYPE_INFO_TOGGLEDISPLAY |
		CUSTOMDATATYPE_INFO_HASSUBDESCRIPTION,
		NewObjClear(LayersCustomDataTypeClass),
		1))
		return false;


	static BaseCustomGuiLib myStringGUIlib;

	ClearMem(&myStringGUIlib, sizeof(myStringGUIlib));
	FillBaseCustomGui(myStringGUIlib);

	if (!InstallLibrary(ID_CUSTOMGUI_LAYERS, &myStringGUIlib, 1000, sizeof(myStringGUIlib)))
		return false;

	if (!RegisterCustomGuiPlugin(GeLoadString(IDS_CUSTOMGUISTRING), 0, NewObjClear(DelightCustonGuiLayers)))
		return false;

	return true;
}


