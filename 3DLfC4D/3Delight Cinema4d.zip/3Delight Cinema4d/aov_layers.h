#ifndef _AOV_LAYERS_H_
#define _AOV_LAYERS_H_

#include "c4d.h"




class LayersCustomDataTypeClass; // forward declaration

class iCustomDataTypeLayers : public iCustomDataType<iCustomDataTypeLayers>
{
	friend class LayersCustomDataTypeClass;

public:

	maxon::BaseArray<maxon::String> _SelectedLayers;
	maxon::BaseArray<maxon::Int32> _selectedId;
	maxon::BaseArray<maxon::Bool> m_output_to_framebuffer;
	maxon::BaseArray<maxon::Bool> m_output_to_file;
	maxon::BaseArray<maxon::Bool> m_output_to_jpeg;
	bool check = true;
	iCustomDataTypeLayers()
	{

	}
};

class AOVDialog : public GeDialog
{

private:
	SimpleListView				Shading_Listview;
	SimpleListView				Auxiliary_Listview;
	AutoAlloc<BaseSelect>	selection;

	void UpdateButtons();

public:
	AOVDialog();
	virtual ~AOVDialog();
	maxon::BaseArray<String> m_selected;
	maxon::BaseArray<Int32> m_selectedID;
	virtual Bool CreateLayout();
	virtual Bool InitValues();
	virtual Bool Command(Int32 id, const BaseContainer& msg);
	virtual Int32 Message(const BaseContainer& msg, BaseContainer& result);
	iCustomDataTypeLayers* _data;

};


#endif
